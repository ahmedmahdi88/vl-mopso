function f=weierstrass_stybtang(x)
f(1)=Weierstrass(x);
f(2)=stybtang(x);
end