function f=levy_powell_stybtang(x)
f(1)=levy(x);
f(2)=powell(x);
f(3)=stybtang(x);
end