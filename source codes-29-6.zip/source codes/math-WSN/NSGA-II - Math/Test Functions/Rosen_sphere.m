function f=Rosen_sphere(x)
f(1)=RosenbrockObjFun(x);
f(2)=-sum(x.^2);
end