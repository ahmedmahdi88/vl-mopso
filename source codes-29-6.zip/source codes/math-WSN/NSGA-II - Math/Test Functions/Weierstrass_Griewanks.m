function f=Weierstrass_Griewanks(x)
f(1)=Weierstrass(x);
f(2)=-Griewanks(x);
end