currentFolder = pwd;
% while ~strcmp(currentFolder(end-1:end),'#\')
%     currentFolder(end) = [];
% end
% addpath([currentFolder 'Codes\Evaluation Metrics'])
% addpath([currentFolder 'Dataset\True pareto front data set'])
addpath([currentFolder '\Test Functions'])
addpath([currentFolder '\new math functions'])
