currentFolder = pwd;

addpath([ currentFolder '/CODE/Test Functions']);
addpath([ currentFolder '/CODE/VLMOPSO']);



