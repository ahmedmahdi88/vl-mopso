function rastrigin_stybtang(x)
f(1)=rastrigin(x);
f(2)=stybtang(x);
end