function f=Rosen_Griewanks(x)
f(1)=RosenbrockObjFun(x);
f(2)=-Griewanks(x);
end