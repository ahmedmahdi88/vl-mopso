function f=Rosen_Ackley(x)
f(1)=RosenbrockObjFun(x);
f(2)=Ackley(x);
end