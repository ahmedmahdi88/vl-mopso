function f=stybtang_Griewanks_Schwefel(x)
f(1)= stybtang(x);
f(2)= Griewanks(x);
f(3)= Schwefel(x);
end
