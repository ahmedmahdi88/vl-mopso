%% initialization
clear;clc;
%% adding required paths
AddRequiredPaths;
%% input params
popSize=50;
lowerBound_pos=0;
heigherBound_pos=1;
lowerBound_dim=2;
higherBound_dim=20;
numberOfIter=200;
RepSize=popSize;
pMutate=0.1;
mutationRatio=0.5;
nGrid=7;
alpha=0.1;
w=0.99;
Vmin=-0.05*(heigherBound_pos-lowerBound_pos);
Vmax=-Vmin;
%% objfunctions
objFuncs = {@MMF14,@MMF15,@MMF14_a,@MMF15_a,@MMF15_l,@MMF15_a_l,@MMF16_l1,...
    @MMF16_l2,@MMF16_l3};
objFunsStrings = {'MMF14','MMF15','MMF14_a','MMF15_a','MMF15_l','MMF15_a_l',...
    'MMF16_l1','MMF16_l2','MMF16_l3'};
nobjs = [2 2 2 2 2 3 3 3 3];
for of = 1:9
    nobj=nobjs(of);
    objfun= objFuncs{of};
for s=1:10
    scenario = s;
    rng(s);
[t,paretoFront,paretoSet ,NC,classes,pop]=RunAlgorithm(s,objfun,popSize,nobj,RepSize,lowerBound_pos,heigherBound_pos,lowerBound_dim,higherBound_dim,nGrid,alpha,numberOfIter,w,pMutate,mutationRatio,Vmin,Vmax);
 currentFolder=pwd;
path2 =[cd '/../../../results/' objFunsStrings{of} '/m-MOPSO/scenario-' num2str(scenario) '\scenario-' num2str(scenario) '.mat' ];
if ~exist(path2, 'dir')
       mkdir(path2)
end
objFcn=objfun;
save([path2 '\scenario-' num2str(s) ] ,'t','paretoFront','paretoSet','NC','classes','popSize','pop','objFcn','higherBound_dim');
end
end