currentFolder = pwd;

addpath([ currentFolder '/CODE/Test Functions']);
addpath([ currentFolder '/CODE/VLMOPSO']);
addpath([ currentFolder '/CODE/new math functions']);



