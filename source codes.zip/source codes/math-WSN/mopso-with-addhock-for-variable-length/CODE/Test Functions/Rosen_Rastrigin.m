function f=Rosen_Rastrigin(x)
f(1)=RosenbrockObjFun(x);
f(2)=-Rastrigin(x);
end