function f=rastrigin_stybtang(x)
f(1)=Rastrigin(x);
f(2)=stybtang(x);
end