function f=sphere(x)
f=sum(x.^2);
end