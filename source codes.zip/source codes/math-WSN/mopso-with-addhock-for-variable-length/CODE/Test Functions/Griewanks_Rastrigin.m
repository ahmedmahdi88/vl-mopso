function f=Griewanks_Rastrigin(x)
f(1)=Griewanks(x);
f(2)=-Rastrigin(x);
end