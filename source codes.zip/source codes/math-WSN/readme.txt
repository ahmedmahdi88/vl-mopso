for each algorithm 
1- for mathematical problems
just modify objective function, and search space and other parameters then run mainFileMath

2- for WSN, run mainFileSensor
3- for mobileSink, run mainFileSink