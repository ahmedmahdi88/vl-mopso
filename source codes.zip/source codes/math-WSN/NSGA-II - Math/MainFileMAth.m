clc
clear
close all

AddRequiredPaths

objFuncs = {@MMF14,@MMF15,@MMF14_a,@MMF15_a,@MMF15_l,@MMF15_a_l,@MMF16_l1,...
    @MMF16_l2,@MMF16_l3};
objFunsStrings = {'MMF14','MMF15','MMF14_a','MMF15_a','MMF15_l','MMF15_a_l',...
    'MMF16_l1','MMF16_l2','MMF16_l3'};
nobjs = [2 2 2 2 2 3 3 3 3];
for of = 1:9
    nobj=nobjs(of);
    ObjectiveFunction =objFuncs{of}; % eval(['@' objfunList{seed}]);
numberOfObjectives = nobjs(of);

for seed = 1:10
    tic;
    rng(seed);
    scenarioName = ['Scenario-' num2str(seed)];
    path2 =[cd '/../../../results/' objFunsStrings{of} '/NSGA-II/' scenarioName '/'];
%     addpath(path2);
    if ~exist(path2, 'dir')
       mkdir(path2)
    end

    % handle the objective function by its name
    lowerDim=2;
    higherDim=20;
    numberOfComponents = higherDim;
    lowerBounds = 0*ones(1,numberOfComponents);
    upperBounds =  1*ones(1,numberOfComponents);
    
    MainFile;
   t(seed)=toc; 
end
end
