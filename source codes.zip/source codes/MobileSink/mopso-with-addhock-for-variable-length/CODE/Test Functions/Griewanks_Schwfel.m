function f=Griewanks_Schwfel(x)
f(1)=Griewanks(x);
f(2)=-Schwefel(x);
end