function f= TestFunction1(x)

% if x1<0
%     x1=0;
% end
% 
% if x2>1
%     x2=1;
% end
% 
% alpha= 2;
% q= 4;
% 
% f1= x1;
% f2= (1+10*x2)*(1-(x1/1+10*x2)^alpha - (x1/(1+10*x2))*sin(2*pi*q*x));
f=[x(1) x(2)];
end