function f=Weierstrass_DRastrigin(x)
f(1)=-Weierstrass(x);
f(2)=DRastrigin(x);
end