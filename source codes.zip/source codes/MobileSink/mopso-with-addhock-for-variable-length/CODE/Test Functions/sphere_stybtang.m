function f=sphere_stybtang(x)
f(1)=sphere(x);
f(2)=stybtang(x);
end