Select wich Scenario you need to visualize in "AddRequiredPAths.m"

you can visualize set coverage comparison by running "setCoverageVisualizationComp" m file

you can run Hyper volume visualization by running "HvVisualizationComp" m file

you can run all visualization by running "MainFile.m"
