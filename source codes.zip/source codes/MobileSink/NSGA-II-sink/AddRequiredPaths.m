
currentFolder = pwd;
addpath([currentFolder])

