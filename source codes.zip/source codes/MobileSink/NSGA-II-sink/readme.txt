This project solves "Task Allocation" problem using binary NSGA-II Algorithm

run MainFileTask.m to generate the resuts for Task Allocation problem with 10 scenarios

you can find the results in Results/DAES/Scenario-(number of scenario)

you can change algorithm parameters by modifing "MAinFile.m" file

you can change "number of iterations" and "number of solutions" by modifing "MAinFile.m" file 
